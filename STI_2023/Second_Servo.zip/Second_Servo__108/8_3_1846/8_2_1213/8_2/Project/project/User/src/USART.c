
#include "main.h"

uint8_t Screen_rxbuffer[Screen_BUFFERSIZE];	
uint8_t Old_OpenMV_rxbuffer[Old_OpenMV_BUFFERSIZE];
uint8_t JY60_rxbuffer[JY60_BUFFERSIZE];



/**
	* @brief  串口通信
  * @param  
  * @retval 无
  */
void USART1_Init(void)
{
		GPIO_InitTypeDef	gpio_init;
		USART_InitTypeDef	usart_init;
		NVIC_InitTypeDef NVIC_InitStruct;
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
		
		//TX-->PA9			RX-->PA10
		gpio_init.GPIO_Pin=GPIO_Pin_9;
		gpio_init.GPIO_Mode=GPIO_Mode_AF_PP;
		gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&gpio_init);
		
		gpio_init.GPIO_Pin=GPIO_Pin_10;
		gpio_init.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA,&gpio_init);				

		NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStruct);

		//配置USART	 默认9600
		usart_init.USART_BaudRate=9600;
		//通信+接收
		usart_init.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
		//流控 无
		usart_init.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
		//结束位 1
		usart_init.USART_StopBits=USART_StopBits_1;
		//单元数据长度 8
		usart_init.USART_WordLength=USART_WordLength_8b;
		//奇偶校验位 偶校验
		usart_init.USART_Parity=USART_Parity_No;
		USART_Init(USART1,&usart_init);
	
	{								
		DMA_InitTypeDef		DMA_InitStruct;													//DMA初始化机构提
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);					//打开DMA1时钟（挂载在AHB总线上）
			
		USART_DMACmd(USART1,USART_DMAReq_Rx,ENABLE);		//使能串口-接收DMA			
		DMA_InitStruct.DMA_BufferSize=Screen_BUFFERSIZE;	//缓冲区长度
		DMA_InitStruct.DMA_PeripheralBaseAddr=(uint32_t)&(USART1->DR);	//源地址
		DMA_InitStruct.DMA_MemoryBaseAddr=(uint32_t)Screen_rxbuffer;	//目标数据地址
		DMA_InitStruct.DMA_PeripheralDataSize=DMA_PeripheralDataSize_Byte;
		DMA_InitStruct.DMA_MemoryDataSize=DMA_MemoryDataSize_Byte;
		DMA_InitStruct.DMA_Mode=DMA_Mode_Circular;
		DMA_InitStruct.DMA_Priority=DMA_Priority_High;
		DMA_InitStruct.DMA_M2M=DMA_M2M_Disable;
		DMA_InitStruct.DMA_DIR=DMA_DIR_PeripheralSRC;
		DMA_InitStruct.DMA_MemoryInc=DMA_MemoryInc_Enable;
		DMA_InitStruct.DMA_PeripheralInc=DMA_PeripheralInc_Disable;
		DMA_Init(DMA1_Channel5,&DMA_InitStruct);
		DMA_Cmd(DMA1_Channel5,ENABLE);
	}
		USART_ITConfig(USART1,USART_IT_IDLE,ENABLE);		//使能空闲中断
		USART_Cmd(USART1,ENABLE);		//使能USART1
}

/**
  * @brief  陀螺仪串口通信(默认波特率是9600）
  * @param  无
  * @retval 无
  */
void USART2_Init(void)
{
		GPIO_InitTypeDef	gpio_init;
		USART_InitTypeDef	usart_init;
		NVIC_InitTypeDef NVIC_InitStruct;
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
		
		//TX-->PA2			RX-->PA3
		gpio_init.GPIO_Pin=GPIO_Pin_2;
		gpio_init.GPIO_Mode=GPIO_Mode_AF_PP;
		gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&gpio_init);
		
		gpio_init.GPIO_Pin=GPIO_Pin_3;
		gpio_init.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA,&gpio_init);				

		NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStruct);

	//配置USART	 
	usart_init.USART_BaudRate=9600;
	//通信+接收
	usart_init.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	//流控 无
	usart_init.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	//结束位 1
	usart_init.USART_StopBits=USART_StopBits_1;
	//单元数据长度 8
	usart_init.USART_WordLength=USART_WordLength_8b;
	//奇偶校验位 偶校验
	usart_init.USART_Parity=USART_Parity_No;
	USART_Init(USART2,&usart_init);
	
	{								
		DMA_InitTypeDef		DMA_InitStruct;													//DMA初始化机构提
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);					//打开DMA1时钟（挂载在AHB总线上）
		
		USART_DMACmd(USART2,USART_DMAReq_Rx,ENABLE);							
		DMA_InitStruct.DMA_BufferSize=JY60_BUFFERSIZE;
		DMA_InitStruct.DMA_PeripheralBaseAddr=(uint32_t)&(USART2->DR);
		DMA_InitStruct.DMA_MemoryBaseAddr=(uint32_t)JY60_rxbuffer;
		DMA_InitStruct.DMA_PeripheralDataSize=DMA_PeripheralDataSize_Byte;
		DMA_InitStruct.DMA_MemoryDataSize=DMA_MemoryDataSize_Byte;
		DMA_InitStruct.DMA_Mode=DMA_Mode_Circular;
		DMA_InitStruct.DMA_Priority=DMA_Priority_High;
		DMA_InitStruct.DMA_M2M=DMA_M2M_Disable;
		DMA_InitStruct.DMA_DIR=DMA_DIR_PeripheralSRC;
		DMA_InitStruct.DMA_MemoryInc=DMA_MemoryInc_Enable;
		DMA_InitStruct.DMA_PeripheralInc=DMA_PeripheralInc_Disable;
		DMA_Init(DMA1_Channel6,&DMA_InitStruct);
		DMA_Cmd(DMA1_Channel6,ENABLE);
	}
	USART_ITConfig(USART2,USART_IT_IDLE,ENABLE);		//使能空闲中断
	USART_Cmd(USART2,ENABLE);
}


/**
	* @brief  OpenMV串口通信  USART3
  * @param  
  * @retval 无
  */
void USART3_Init(void)
{
		GPIO_InitTypeDef	gpio_init;
		USART_InitTypeDef	usart_init;
		NVIC_InitTypeDef NVIC_InitStruct;
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
		
		//TX-->PB10			RX-->PB11
		gpio_init.GPIO_Pin=GPIO_Pin_10;
		gpio_init.GPIO_Mode=GPIO_Mode_AF_PP;
		gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOB,&gpio_init);
		
		gpio_init.GPIO_Pin=GPIO_Pin_11;
		gpio_init.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOB,&gpio_init);				

		NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStruct);

		//配置USART	 默认9600
		usart_init.USART_BaudRate=115200;
		//通信+接收
		usart_init.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
		//流控 无
		usart_init.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
		//结束位 1
		usart_init.USART_StopBits=USART_StopBits_1;
		//单元数据长度 8
		usart_init.USART_WordLength=USART_WordLength_8b;
		//奇偶校验位 偶校验
		usart_init.USART_Parity=USART_Parity_No;
		USART_Init(USART3,&usart_init);
	
	{								
		DMA_InitTypeDef		DMA_InitStruct;													//DMA初始化机构提
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);					//打开DMA1时钟（挂载在AHB总线上）
			
		USART_DMACmd(USART3,USART_DMAReq_Rx,ENABLE);							
		DMA_InitStruct.DMA_BufferSize=Old_OpenMV_BUFFERSIZE;
		DMA_InitStruct.DMA_PeripheralBaseAddr=(uint32_t)&(USART3->DR);
		DMA_InitStruct.DMA_MemoryBaseAddr=(uint32_t)Old_OpenMV_rxbuffer;
		DMA_InitStruct.DMA_PeripheralDataSize=DMA_PeripheralDataSize_Byte;
		DMA_InitStruct.DMA_MemoryDataSize=DMA_MemoryDataSize_Byte;
		DMA_InitStruct.DMA_Mode=DMA_Mode_Circular;
		DMA_InitStruct.DMA_Priority=DMA_Priority_High;
		DMA_InitStruct.DMA_M2M=DMA_M2M_Disable;
		DMA_InitStruct.DMA_DIR=DMA_DIR_PeripheralSRC;
		DMA_InitStruct.DMA_MemoryInc=DMA_MemoryInc_Enable;
		DMA_InitStruct.DMA_PeripheralInc=DMA_PeripheralInc_Disable;
		DMA_Init(DMA1_Channel3,&DMA_InitStruct);
		DMA_Cmd(DMA1_Channel3,ENABLE);
	}
		USART_ITConfig(USART3,USART_IT_IDLE,ENABLE);
		USART_Cmd(USART3,ENABLE);			
}



/**
	* @brief  发送单个字节
  * @param  ch					数据
	* @param  USART_TYPE  目标串口
  * @retval 无
  */
void USART_SendByte(USART_TypeDef*	USART_TYPE,uint8_t ch)
{
	USART_SendData(USART_TYPE,ch);

	while(USART_GetFlagStatus(USART_TYPE,USART_FLAG_TXE)==RESET);
}


/**
* @brief  发送整个字符串
  * @param  str					数据数组
	* @param  USART_TYPE  目标串口
  * @retval 无
  */
void USART_SendString(USART_TypeDef* USART_TYPE,uint8_t* str)
{
	uint16_t i=0;
	do
	{
		USART_SendByte(USART_TYPE,*(str+i));
		i++;
	}while(*(str+i)!='\0');
}

/**
* @brief  发送整个数组
  * @param	USART_TYPE	目标串口
  * @param  array				数据数组
	* @param  num  				数组长度
  * @retval 无
  */

 
void USART_SendArray(USART_TypeDef *USART_TYPE, uint8_t *array,uint32_t num)
{
		unsigned char i=0;//定义一个局部变量用来 发送字符串 ++运算
		while(i < num)
		{
			USART_SendByte(USART_TYPE,array[i]);//通过库函数发送数据
			i++;//值 加一
		}
}


/**
	* @brief  CRC校验和
  * @param  buff	数组
  * @param  len		要终止的位置
  * @retval 无
  */
static uint16_t CRC_Check_Sum(uint8_t* buff, uint16_t len)
{
    uint16_t checksum=0;
    while(len--) checksum+=*buff++;
    return (checksum&0xFF);
}



/**
	* @brief  USART1中断处理函数    
  * @param  
  * @retval 无
  */
uint8_t state;	//状态位
extern uint8_t task_pointer;	//任务指针
uint8_t state_change_flag;	//状态切换标志位
uint8_t target_sequence[4];
extern uint8_t if_usart_send;		//串口标志位
void USART1_IRQHandler(void)
{	
	uint16_t	len;	//数据长度
	if(USART_GetFlagStatus(USART1,USART_FLAG_IDLE)!=RESET)
	{
		(void)USART1->SR;
		(void)USART1->DR;
		len = Screen_BUFFERSIZE-DMA_GetCurrDataCounter(DMA1_Channel5);	//计算接收帧长度
		DMA_Cmd(DMA1_Channel5,DISABLE);
		DMA_SetCurrDataCounter(DMA1_Channel5,Screen_BUFFERSIZE);		//重新设置缓冲区长度,从基地址接收
		if(len == 3){
			if(Screen_rxbuffer[0] ==0X5A	&& Screen_rxbuffer[2] == 0XEF)
			{
				if(state!=Screen_rxbuffer[1])
				{
					state_change_flag = 1;
				}
				state = Screen_rxbuffer[1];		//任务状态标志位
				if(state == 0x04)
				{
					if_usart_send = 1;
				}
			}
		}
		DMA_Cmd(DMA1_Channel5,ENABLE);
	}
}




/**
	* @brief  USART2中断处理函数  陀螺仪
  * @param  
  * @retval 无
  */
uint16_t USART2_Receive_Flag;
void USART2_IRQHandler(void)
{
	uint16_t	len;	//数据长度
	if(USART_GetFlagStatus(USART2,USART_FLAG_IDLE)!=RESET)		//判断是否为IDLE中断
	{
		(void)USART2->SR;				//先读SR寄存器，再读DR寄存器能够清除IDLE标志位
		(void)USART2->DR;
		len = JY60_BUFFERSIZE-DMA_GetCurrDataCounter(DMA1_Channel6);	//计算接收帧长度
		DMA_Cmd(DMA1_Channel6,DISABLE);
		DMA_SetCurrDataCounter(DMA1_Channel6,JY60_BUFFERSIZE);		//重新设置缓冲区长度,从基地址接收
		
		{
			USART2_Receive_Flag = 1;
			JY60_Rec(JY60_rxbuffer);
		}

		DMA_Cmd(DMA1_Channel6,ENABLE);
	}
}

/**
	* @brief  USART3中断处理函数   openmv
  * @param  
  * @retval 无
  */
uint8_t update_flag;	//接受标志位;	
uint32_t reset_wait_time = 20;		//上电取坐标原点
float camera_x;			//X位置
float camera_y;			//Y位置
//uint8_t shape_type;		//形状
float test_x;
float test_y;
float temp_x;
float temp_y;

uint8_t middle_x;
uint8_t middle_y;
uint8_t motion_flag;		//决定是否追踪
Points_of_A4 points_of_A4;
float point_axis[5][2];
extern float zero_x;			//x的坐标原点
extern float zero_y;			//y的坐标原点
uint8_t calibarate_flag;

void USART3_IRQHandler(void)
{
	uint16_t	len;	//数据长度
	if(USART_GetFlagStatus(USART3,USART_FLAG_IDLE)!=RESET)		//判断是否为IDLE中断
	{
		(void)USART3->SR;				//先读SR寄存器，再读DR寄存器能够清除IDLE标志位
		(void)USART3->DR;
		len = Old_OpenMV_BUFFERSIZE-DMA_GetCurrDataCounter(DMA1_Channel3);	//计算接收帧长度
		DMA_Cmd(DMA1_Channel3,DISABLE);
		if(len == 10){
				if(Old_OpenMV_rxbuffer[0] == 0x5a && Old_OpenMV_rxbuffer[9] == 0xef){	
					uint32_t maxx_index=1,minx_index=1,maxy_index=2,miny_index = 2;
					for(int i=0;i<4;i++)
					{
						if(Old_OpenMV_rxbuffer[1+i*2] > Old_OpenMV_rxbuffer[maxx_index])
							maxx_index = 1+2*i;
						if(Old_OpenMV_rxbuffer[1+i*2] < Old_OpenMV_rxbuffer[minx_index])
							minx_index = 1+2*i;
						if(Old_OpenMV_rxbuffer[2+i*2] > Old_OpenMV_rxbuffer[maxy_index])
							maxy_index = 2+2*i;
						if(Old_OpenMV_rxbuffer[2+i*2] < Old_OpenMV_rxbuffer[miny_index])
							miny_index = 2+2*i;
					}
					
					Old_OpenMV_rxbuffer[maxx_index] -=4;
					Old_OpenMV_rxbuffer[minx_index] +=4;
					Old_OpenMV_rxbuffer[maxy_index] -=4;
					Old_OpenMV_rxbuffer[miny_index] +=4;
					
					point_axis[0][0] = Old_OpenMV_rxbuffer[1];
					point_axis[0][1]= Old_OpenMV_rxbuffer[2];
					point_axis[1][0] = Old_OpenMV_rxbuffer[3];
					point_axis[1][1]= Old_OpenMV_rxbuffer[4];
					point_axis[2][0] = Old_OpenMV_rxbuffer[5];
					point_axis[2][1] = Old_OpenMV_rxbuffer[6];
					point_axis[3][0] = Old_OpenMV_rxbuffer[7];
					point_axis[3][1] = Old_OpenMV_rxbuffer[8];
					point_axis[4][0] = point_axis[0][0] ;
					point_axis[4][1] = point_axis[0][1]	;
					
					lazer_on();
					if_usart_send = 3;
				}
		}
		if(len == 4)
		{
			temp_x = test_x;
			temp_y = test_y;
			camera_x = Old_OpenMV_rxbuffer[1];			//第二个云台的是当前红点的坐标
			camera_y = Old_OpenMV_rxbuffer[2];
			test_x = 0.3858*camera_x +(1-0.3858)*temp_x;	//低通滤波
			test_y = 0.3858*camera_y +(1-0.3858)*temp_y;
			update_flag = 1;
			if(reset_wait_time)
			{
				reset_wait_time--;
			}
			else if(reset_wait_time ==0)
			{
				zero_x = camera_x;
				zero_y = camera_y;
				calibarate_flag = 1;
				reset_wait_time = -1;
			}
		}
		DMA_SetCurrDataCounter(DMA1_Channel3,Old_OpenMV_BUFFERSIZE);		//重新设置缓冲区长度,从基地址接收
		DMA_Cmd(DMA1_Channel3,ENABLE);
	}
}



/**
	* @brief  USART3解码函数   openmv
  * @param  
  * @retval 无
  */
int UPDATE_FALG;
int flag, type;
int x,y;
uint8_t getdata(uint8_t *text)
{
	UPDATE_FALG = 1;
	return 1;
}

uint8_t link_state =1;	//1为已连接 0为未连接

void Check_link(void)
{
	if(GPIO_ReadInputDataBit(STA_GPIO,STA_PIN)==0)	link_state =0;
	else link_state = 1;
}

