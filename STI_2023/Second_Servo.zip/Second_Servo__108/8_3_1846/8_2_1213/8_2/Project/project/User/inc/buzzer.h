#ifndef __BUZZER_H__
#define __BUZZER_H__

#define BUZZER_GPIO GPIOA
#define BUZZER_PIN	GPIO_Pin_12

void buzzer_Init(void);
void buzzer_on(void);
void buzzer_off(void);

#endif
