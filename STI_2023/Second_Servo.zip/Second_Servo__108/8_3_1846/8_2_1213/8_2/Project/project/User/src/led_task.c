
#include "main.h"

void MY_LED_init(void)
{
	GPIO_InitTypeDef gpio_init;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);

	gpio_init.GPIO_Pin=GPIO_Pin_13;
	gpio_init.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&gpio_init);
}


void led_task(void *pvParameters)
{	
	while(1)
	{						
    LED_ON;
    vTaskDelay(500);   /* ��ʱ500��tick */
		
    LED_OFF;     
    vTaskDelay(500);   /* ��ʱ500��tick */		 		
	}
}

