#ifndef __AD_H
#define __AD_H

#include "stm32f10x.h"

void AD_Init(void);
uint16_t middleAverageFilter(void);
float Get_Angle(void);

#endif
