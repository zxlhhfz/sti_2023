
#ifndef __LED_TASK_H
#define	__LED_TASK_H

void led_task(void *pvParameters);

#define LED_ON 		GPIO_ResetBits(GPIOC,GPIO_Pin_13)
#define LED_OFF 	GPIO_SetBits(GPIOC,GPIO_Pin_13)

void MY_LED_init(void);

#endif
