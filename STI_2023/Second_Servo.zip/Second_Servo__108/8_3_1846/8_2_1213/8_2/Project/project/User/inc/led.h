
#ifndef __LED_H
#define __LED_H

#include "stm32f10x.h"

enum my_LED
{
	YELLOW = 0,
	RED,
	GREEN
};

#define YELLOW_RCC	RCC_APB2Periph_GPIOB
#define GREEN_RCC		RCC_APB2Periph_GPIOB
#define RED_RCC			RCC_APB2Periph_GPIOB
#define YELLOW_GPIO	GPIOB
#define YELLOW_GPIO_PIN	GPIO_Pin_9
#define GREEN_GPIO GPIOB
#define GREEN_GPIO_PIN	GPIO_Pin_4
#define RED_GPIO GPIOB
#define RED_GPIO_PIN		GPIO_Pin_6

#define my_pin 			GPIO_Pin_10

uint8_t LED_init(void);
uint8_t led_on(uint8_t color);
uint8_t led_off(uint8_t color);
uint8_t Check_State(void);

uint8_t Check_mass(void);

#endif
