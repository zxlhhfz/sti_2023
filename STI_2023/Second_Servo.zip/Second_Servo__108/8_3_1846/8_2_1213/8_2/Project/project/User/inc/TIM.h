
#ifndef __TIM_H
#define __TIM_H

#include "stm32f10x.h"

#define BASIC_SPEED 0.50


#define LEFT_DIRECTION_CONTROL_IO  GPIOB
#define RIGHT_DIRECTION_CONTROL_IO GPIOB

#define LEFT_1_DIRECTION_CONTROL_PIN  GPIO_Pin_4
#define LEFT_2_DIRECTION_CONTROL_PIN  GPIO_Pin_5
#define RIGHT_1_DIRECTION_CONTROL_PIN  GPIO_Pin_7
#define RIGHT_2_DIRECTION_CONTROL_PIN  GPIO_Pin_6

void TIM4_PWM_Init(int arr, int psc);
void TIM3_PWM_Init(int arr, int psc);
void Encoder_TIM5_Init(void);
void Encoder_TIM8_Init(void);
void Encoder_TIM1_Init(void);
int16_t Read_Encoder(TIM_TypeDef *TIMx);
void Set_PWM(void);

void Encoder_Init_TIM2(void);
void search_line_towards(void);
void search_line_backwards(void);


uint16_t Encoder_Get_R(void);
uint16_t Encoder_Get_L(void);

#endif
