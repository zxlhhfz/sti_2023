#include "main.h"

uint8_t LED_init(void)
{
	GPIO_InitTypeDef gpio_init;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_NoJTRST, ENABLE);
	
	//LED I/O��ʼ��
	gpio_init.GPIO_Pin=YELLOW_GPIO_PIN;
	gpio_init.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(YELLOW_GPIO,&gpio_init);
	
	gpio_init.GPIO_Pin=RED_GPIO_PIN;
	gpio_init.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(RED_GPIO,&gpio_init);
	
	gpio_init.GPIO_Pin=GREEN_GPIO_PIN;
	gpio_init.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio_init);
	
	//����I/O��ʼ��
	gpio_init.GPIO_Pin=my_pin;
	gpio_init.GPIO_Mode=GPIO_Mode_IPD;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&gpio_init);
	
	return 1;
}

/**
	* @brief  ����
  * @param  
  * @retval ��
  */
uint8_t led_on(uint8_t color)
{
	if(color == YELLOW)
		GPIO_WriteBit(YELLOW_GPIO,YELLOW_GPIO_PIN,1);
	else if(color == RED)
		GPIO_WriteBit(RED_GPIO,RED_GPIO_PIN,1);
	else if(color == GREEN)
		GPIO_WriteBit(GREEN_GPIO,GREEN_GPIO_PIN,1);
	else
		return ERROR;
	
	return 1;
}

/**
	* @brief  ����
  * @param  
  * @retval ��
  */
uint8_t led_off(uint8_t color)
{
	if(color == YELLOW)
		GPIO_WriteBit(YELLOW_GPIO,GPIO_Pin_9,0);
	else if(color == RED)
		GPIO_WriteBit(RED_GPIO,RED_GPIO_PIN, 0);
	else if(color == GREEN)
		GPIO_WriteBit(GREEN_GPIO,GREEN_GPIO_PIN, 0);
	else
		return ERROR;
	
	return 1;
}
extern uint8_t state;		//״̬λ
extern uint8_t last_state;	//��һ�ε�״̬
/**
	* @brief  ���ؼ�⺯���������л�״̬���͵�ƽΪ����
  * @param  
  * @retval ��
  */
uint8_t Check_State(void)
{
	uint8_t temp;
	temp = GPIO_ReadInputDataBit(GPIOC,my_pin);
	if(temp ==0)
	{
		return 1;
	}
	else if(temp == 1)
	{
		return 0;
	}

}
