
#ifndef __COMMUNICATE_TASK_H
#define	__COMMUNICATE_TASK_H

#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"

void communicate_task(void *pvParameters);

#endif
