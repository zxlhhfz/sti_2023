#ifndef DELAY_H
#define DELAY_H

#include "stm32f10x.h"

void Systick_Init(void);
void delay_us(uint32_t nus);
void delay_ms(uint32_t nms);

#endif
