
#include "main.h"

// ������������תһȦ�����������������ȣ�Ϊ13�����ٱ�Ϊ1��20��Ҳ���ǵ��תһȦ
// ������ת20Ȧ��Ƶ��Ϊ100HZ��AB˫����ϵõ�4��Ƶ�����Ҳ�֪��ʲô��˼��
// ���ת��Ϊ n = Encoder *100 /(13*20*4) r/s���ǵý�������ֵת��Ϊԭ�룩

/*PID*/
Car_typedef car;		//С���ṹ��
Servo_typedef servo;	//��̨�ṹ��
Step_Motor step_Motor_yaw;		//��������ṹ�壨YAW�ᣩ
Step_Motor step_Motor_pitch;	//PITCH��

/*�û�����ֵ*/
extern uint8_t init_flag;	//��ʼ����־λ
extern uint8_t update_flag;	//���ܱ�־λ
extern uint8_t state;	//��ǰ�˶�״̬λ
extern Points_of_A4 points_of_A4; // A4ֽ�ĵ�����ṹ��

uint32_t stop_cnt;	//ͣ����ʱλ
uint8_t servo_cnt;	//�����ʱλ
uint8_t auto_fire_flag;		//�ж��Ƿ�����i

float zero_x;			//x������ԭ��
float zero_y;			//y������ԭ��

uint8_t last_state;	//��һ�ε�״̬


/**
  * @brief  ������ʼ��
  * @param  ��
  * @retval ��
  */
void Ref_Init()
{
	//Yaw-
	Motor_Ref_Init(&step_Motor_yaw);
	//Pitch
	Motor_Ref_Init(&step_Motor_pitch);
	
	
	//��̨׷���PID
	//PID_Ref_Init(&step_Motor_yaw.PID,5.0f,0.00f,0.5f,1.0f,3,70);
	PID_Ref_Init(&step_Motor_yaw.PID,4.0f,0.00f,0.5f,1.0f,3,70);
	step_Motor_yaw.PID.e0 = 2;
	PID_Ref_Init(&step_Motor_pitch.PID,5.0,0.0f,-2.0f,1.0f,3,70);
	step_Motor_yaw.PID.e0 = 2;
}

void control_task(void *pvParameters)
{
	portTickType xLastWakeTime;					//�ϴ�ϵͳʱ��
	const portTickType xFrequency = 15; // ����Ƶ��100HZ���ڶ�����̨����Ƶ��Ҫ��һ�㣩
	
	Ref_Init();
	
	while(1)
	{	
		xLastWakeTime = xTaskGetTickCount();		//��ȡ�ϴ�ʱ��
		
		if(init_flag)
		{				
			Task_Update();		//��������״̬	
			//Follow_Mode();
		}			
		vTaskDelayUntil(&xLastWakeTime,xFrequency);
	}
}

extern uint32_t calibarate_flag;
extern float camera_x;			//Xλ��
extern float camera_y;			//Yλ��
int reset_time;
uint8_t reset_update_flag;

void PID_Reset(void)
{
	float reset_yaw,reset_pitch;
	
	if(calibarate_flag)
	{
		if(reset_time<RESET_TIME)
		{
			step_Motor_yaw.setpoint = camera_x + reset_time*(zero_x -camera_x)/RESET_TIME;
			step_Motor_pitch.setpoint = camera_y + reset_time*(zero_y -camera_y)/RESET_TIME;
			
			reset_yaw = Servo_PID_Cal(&step_Motor_yaw.PID,step_Motor_yaw.setpoint,camera_x);
			reset_pitch = Servo_PID_Cal(&step_Motor_pitch.PID,step_Motor_pitch.setpoint,camera_y);
			reset_time++;
			Gimbal_update(reset_yaw,reset_pitch);
		}
		else if(reset_time==RESET_TIME)
		{
			reset_time =0;
			reset_update_flag = 0x01;
			if(state != 0x07)
				reset_update_flag = 1;
			else
			{
				reset_update_flag = 0;
				state = 0x00;
			}
		}
	}
}

extern uint8_t state_change_flag;
extern uint8_t motion_flag;		//�����Ƿ�׷��
uint8_t reset_pointer;
uint8_t if_usart_send;		//���ڱ�־λ

//�������
int cnt;	
int wait_state;
uint16_t action_pointer;
uint32_t wait_cnt;
uint32_t state_change_cnt;
int complete_flag;
int check_cnt;
int state_cnt;
int my_flag;

//�����л�
void Task_Update(void)
{
	if(state == 0x00)		//��ֹʱ���״̬
	{
		static_state();
		State_Update();
	}
	if(state==1)
	{
	lazer_on();
		led_off(YELLOW);
		led_off(RED);
		led_off(GREEN);
		buzzer_off();
		Follow_Mode();
		State_Update();
	}
	else if(state==2)
	{
		led_off(YELLOW);
		led_off(RED);
		led_off(GREEN);
		
		Follow_Mode();
		State_Update();
	}
	else if(state == 0x04)
	{
		state=0x00;
	}
	if(fabsf(camera_y-step_Motor_pitch.setpoint)<=5  &&fabsf(camera_x-step_Motor_yaw.setpoint)<=5 &&state!=0 )
	{
		check_cnt++;
		if(check_cnt >=0)
		{
			complete_flag=1;
		}
	}
	else
	{
		complete_flag = 0;
	}
	if(complete_flag )
	{
			led_on(RED);
			led_on(GREEN);
			led_on(YELLOW);
			state_cnt++;
			buzzer_on();
		}
		else
		{
			led_off(RED);
			led_off(GREEN);
			led_off(YELLOW);
			buzzer_off();
	}
}

extern uint8_t shape_type;		//��״
extern float test_x;

int if_stop_flag_yaw = 0;		//�Ƿ�ֹͣ��־λ
int if_stop_flag_pitch = 0;		//�Ƿ�ֹͣ��־λ

void State_Update(void)
{
			if(Check_State()==1)
		{
			if(state_change_cnt<=80)
				state_change_cnt++;
			else 
			{
				state_change_cnt = 0;
				if(state==0)
				{
					state=1;
				}
				else if(state==1)
				{
					state = 0;
				}
			}
		}
		else
		{
			state_change_cnt = 0;
		}
}

void static_state(void)
{
}

 int yaw_cnt;
int pitch_cnt;

// ��λ����
void Reset(void)
{	
	if(reset_pointer ==0)
	{
		Gimbal_update(-step_Motor_yaw.current_pulse,-step_Motor_pitch.current_pulse);
		reset_pointer = 0x01;
	}
	else if(reset_pointer == 0x01)		//��ʱ
	{
		if(cnt<RESET_TIME)
			cnt++;
		else
		{
			reset_pointer = 0x02;
			cnt = 0;
		}
	}
	else if(reset_pointer == 0x02)
	{
		if_stop_flag_yaw = 1;
		if_stop_flag_pitch = 1;
		reset_pointer = 0;//���㣬������
		if(state != 0x07)
			reset_update_flag = 1;
		else
		{
			reset_update_flag = 0;
			state = 0x00;
		}
	}
}

int task_cnt;

// ���1
void Task_1(void)
{
	//׷�ٺ���
	Follow_Mode();
}

// ����2������Ļ��
void Task_2(void)
{
	if(action_pointer == 0x00) // ��500
	{		
		Gimbal_update(-1000,0);
		action_pointer = 0x01;
	}
	else if(action_pointer == 0x01)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x02;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x02) // ��500
	{
		Gimbal_update(0,1000);
		action_pointer = 0x03;
	}
	else if(action_pointer == 0x03)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x04;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x04) // ��1000
	{
		Gimbal_update(2000,0);
		action_pointer = 0x05;
	}	
	else if(action_pointer == 0x05)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x06;
			cnt = 0;
		}	
	}	
	else if(action_pointer == 0x06) // ��1000
	{
		Gimbal_update(0,-2000);
		action_pointer = 0x07;
	}		
	else if(action_pointer == 0x07)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x08;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x08) // ��1000
	{
		Gimbal_update(-2000,0);
		action_pointer = 0x09;
	}		
	else if(action_pointer == 0x09)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x10;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x10) // ��500
	{
		Gimbal_update(0,1000);
		action_pointer = 0x11;
	}		
	
	else if(action_pointer == 0x11)
	{
		if_stop_flag_yaw = 1;
		if_stop_flag_pitch = 1;
		state = 0x00;		//��ֹ״̬
		state_change_flag = 0;
	}	
	
}


extern uint8_t middle_x;
extern uint8_t middle_y;
extern Points_of_A4 points_of_A4;
uint8_t if_wait;
uint8_t move_time_cnt;


// ����4��������A4ֽ��
void Task_4(void)
{

}

// ����5
void Task_5(void)
{
	
}

int CNT=0;
int test_flag;


void Gimbal_update(int yaw_angle,int pitch_angle)
{
	if(yaw_angle>0)		//˳ʱ��ת��һ���Ƕ�
	{
		GPIO_ResetBits(GPIOB,DIR_PIN_YAW);
	}
	else if(yaw_angle<0)
	{
		GPIO_SetBits(GPIOB,DIR_PIN_YAW);
	}
	if(pitch_angle>0)		//˳ʱ��ת��һ���Ƕ�
	{	
		GPIO_SetBits(GPIOB,DIR_PIN_PITCH);
	}
	else if(pitch_angle<0)
	{
		GPIO_ResetBits(GPIOB,DIR_PIN_PITCH);
	}
	
	int temp;

//	{
//		yaw_angle = -YAW_MAX_PULSE - step_Motor_yaw.current_pulse ;
//	}
	
	temp = step_Motor_pitch.current_pulse +pitch_angle;
	
//	if(temp>=PITCH_MAX_PULSE )
//	{
//		pitch_angle =PITCH_MAX_PULSE - step_Motor_pitch.current_pulse ;
//	}
//	else if(temp<=-PITCH_MAX_PULSE)
//	{
//		pitch_angle = -PITCH_MAX_PULSE - step_Motor_pitch.current_pulse ;
//	}
	
	step_Motor_yaw.current_pulse +=(int)yaw_angle;
	step_Motor_pitch.current_pulse += (int)pitch_angle;
	
	temp = abs(yaw_angle);
	
	Pulse_output_YAW(100,temp);
	
	temp = abs(pitch_angle);
	
	Pulse_output_PITCH(100,temp);
}


int test_CNT=0;

extern uint8_t motion_flag;
uint32_t trj_time;
uint32_t number;


float temp_yaw,temp_pitch;
int test_num;

uint32_t last_poi;
extern float point_axis[5][2];

void PID_Test(void)
{
	float temp1,temp2;
	if(motion_flag)
	{
//		point_axis[0][0] = 103 ;
//		point_axis[0][1] = 78 ;
//		point_axis[1][0] = 115;
//		point_axis[1][1] = 31;
//		point_axis[2][0] = 185;
//		point_axis[2][1] = 48;
//		point_axis[3][0] = 172;
//		point_axis[3][1] = 96;
//		point_axis[4][0] = 103;
//		point_axis[4][1] = 78;
			if(update_flag)
			{
				if(action_pointer == 0x00)
				{
				if(CNT<divide)
				{
					if(test_num ==0)
					{
						step_Motor_yaw.setpoint = point_axis[0][0];
						step_Motor_pitch.setpoint = point_axis[0][1] ;
					}
					else if(test_num<0x04)
					{
						step_Motor_yaw.setpoint = point_axis[test_num-1][0] + CNT*(point_axis[test_num][0] -point_axis[test_num-1][0])/divide;
						step_Motor_pitch.setpoint = point_axis[test_num-1][1]  +CNT*(point_axis[test_num][1] -point_axis[test_num-1][1] )/divide;
					}
					else
					{
						step_Motor_yaw.setpoint = point_axis[test_num-1][0] + CNT*(point_axis[0][0] -point_axis[test_num-1][0])/divide;
						step_Motor_pitch.setpoint = point_axis[test_num-1][1]  +CNT*(point_axis[0][1] -point_axis[test_num-1][1] )/divide;
					}
					CNT++;
					if(CNT==divide)
					{
						action_pointer = 0x01;
						CNT = 0;
					}
				temp_yaw = Servo_PID_Cal(&step_Motor_yaw.PID,step_Motor_yaw.setpoint,camera_x);
				temp_pitch = Servo_PID_Cal(&step_Motor_pitch.PID,	step_Motor_pitch.setpoint,camera_y);
					
				if(temp_yaw>PER)
				{
					temp_yaw =PER+2;
				}
				else if(temp_yaw<-PER)
				{
					temp_yaw = -PER-2;
				}
				
				if(temp_pitch>PER)
				{
					temp_pitch =PER;
				}
				else if(temp_pitch<-PER)
				{
					temp_pitch = -PER;
				}
			}
				
		Gimbal_update(temp_yaw,temp_pitch);
	}
				else if(action_pointer == 0x01)
				{
					if(cnt <  10) // 5
						cnt++;
					else
					{
						action_pointer = 0x00;
						cnt = 0;
						if(test_num<=0x04)
						test_num ++;
						else
						{
							if_usart_send = 0;
							state = 0x00;
							test_num = 0;
						}
					}	
				}
		}
	}
}

float test_number;

uint8_t check_state;		//��������Ƿ��ܱȽϺ�ʶ�𵽺�ɫ�����
int complete_flag;

void Follow_Mode(void)				
{
	float yaw_raw_output,pitch_raw_otpuut;		//���ֵ�м����
	step_Motor_yaw.setpoint = CENTER_X;			//��������ֵ

	step_Motor_pitch.setpoint = CENTER_Y;
	if(state)			//���¿��زſ�ʼ׷��
	{	
		if(update_flag)		//���ڸ����˲Ž���PID����
		{
			yaw_raw_output = Servo_PID_Cal(&step_Motor_yaw.PID,step_Motor_yaw.setpoint,camera_x);
			pitch_raw_otpuut = Servo_PID_Cal(&step_Motor_pitch.PID,	step_Motor_pitch.setpoint,camera_y);		
			Gimbal_update(yaw_raw_output,pitch_raw_otpuut);		//���
				
			update_flag = 0;
		}
	}
}


// ����3����̶�A4ֽ��
void Task_3(void)
{
	if(motion_flag)
	{
		if(number!=4)
		{
			if(trj_time <=divide)
			{
				if(update_flag)
				{
					step_Motor_yaw.setpoint += point_axis[0][0]/divide;
					temp_yaw = Servo_PID_Cal(&step_Motor_yaw.PID,point_axis[number][0]/trj_time,camera_x);
					temp_pitch = Servo_PID_Cal(&step_Motor_yaw.PID,point_axis[number][1],camera_y);
					update_flag = 0;
					trj_time++;
				}
			}
			else if(trj_time>divide)
			{
				number++;
				trj_time = 0;
			}
		}
		else{
			state_change_flag = 0;
			if_stop_flag_yaw = 1;
			if_stop_flag_pitch = 1;
			state = 0x00;		//��ֹ״̬
		}
		Gimbal_update(temp_yaw,temp_pitch);
	}
}

int Open_Loop_cnt;

void Open_loop_Task(void)
{
	if(action_pointer == 0x00) // ��500
	{		
		Gimbal_update(-1050,0);
		action_pointer = 0x01;
	}
	else if(action_pointer == 0x01)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x02;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x02) // ��500
	{
		Gimbal_update(0,850);
		action_pointer = 0x03;
	}
	else if(action_pointer == 0x03)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x04;
			cnt = 0;
		}	
	}
	else if(action_pointer == 0x04) // ��1000
	{
		Gimbal_update(1150,0);
		action_pointer = 0x05;
	}	
	else if(action_pointer == 0x05)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x06;
			cnt = 0;
		}	
	}	
	else if(action_pointer == 0x06) // ��1000
	{
		Gimbal_update(0,-800);
		action_pointer = 0x07;
	}		
	else if(action_pointer == 0x07)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x08;
			cnt = 0;
		}	
	}	
	else if(action_pointer == 0x08) // ��1000
	{
		Gimbal_update(-1200,0);
		action_pointer = 0x09;
	}		
	else if(action_pointer == 0x09)
	{
		if(cnt <  50) // 5
			cnt++;
		else
		{
			action_pointer = 0x00;
			cnt = 0;
			state_change_flag = 0;
		}	
	}
}

