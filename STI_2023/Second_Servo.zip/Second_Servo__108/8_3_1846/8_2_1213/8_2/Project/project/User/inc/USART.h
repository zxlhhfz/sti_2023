
#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

#define STA_GPIO GPIOC
#define STA_PIN	 GPIO_Pin_2

#define Screen_BUFFERSIZE 10
#define Old_OpenMV_BUFFERSIZE 20
#define JY60_BUFFERSIZE   50


typedef struct
{
	uint8_t x1;
	uint8_t y1;
	uint8_t x2;
	uint8_t y2;
	uint8_t x3;
	uint8_t y3;
	uint8_t x4;
	uint8_t y4;	
}Points_of_A4;			//// A4ֽ�ĵ�����ṹ��



void USART1_Init(void);
void USART2_Init(void);
void USART3_Init(void);
void USART_SendByte(USART_TypeDef*	USART_TYPE,uint8_t ch);
void USART_SendString(USART_TypeDef* USART_TYPE,uint8_t* str);
void USART_SendArray(USART_TypeDef *USART_TYPE,uint8_t * array,uint32_t num);
void USART1_IRQHandler(void);
void USART2_IRQHandler(void);
void USART3_IRQHandler(void);
uint8_t getdata(uint8_t *text);

void GetData(uint8_t *rx_buffer,float *distance);
void Check_link(void);




#endif

