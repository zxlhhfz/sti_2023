
#ifndef __JY60_H
#define __JY60_H

#include "stm32f10x.h"

typedef struct
{
	float AccX;
	float AccY;
	float AccZ;
	float GyroX;
	float GyroY;
	float GyroZ;
	float AngleX;
	float AngleY;
	float AngleZ;
}JY60_typedef;

#define G		9.8					//�������ٶ�

void JY60_Sendcmd(uint8_t *cmd,uint16_t num);
void JY60_Cal(uint8_t* receive_buff);
static uint16_t CRC_Check_Sum(uint8_t* buff, uint16_t len);
void JY60_Init(void);
void JY60_Rec(uint8_t*);


#endif
