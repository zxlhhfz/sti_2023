#ifndef __GRAYSCALE_SENSOR_H
#define __GRAYSCALE_SENSOR_H

#include "stm32f10x.h"

#define GRAYSCALE_SENSOR_GPIO	GPIOC
#define L2_PIN	GPIO_Pin_13
#define L1_PIN  GPIO_Pin_14
#define M_PIN		GPIO_Pin_15
#define R1_PIN	GPIO_Pin_0
#define R2_PIN	GPIO_Pin_1

void GrayScale_Sensor_GPIO_Init(void);
void GrayScale_Update(void);

#endif
