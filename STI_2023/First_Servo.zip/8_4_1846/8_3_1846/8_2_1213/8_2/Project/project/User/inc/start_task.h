
#ifndef __START_TAKS_H
#define __START_TAKS_H

#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"


void Start_Task(void);
void start_task(void *pvParameters);
void led_task(void *pvParameters);

#endif
