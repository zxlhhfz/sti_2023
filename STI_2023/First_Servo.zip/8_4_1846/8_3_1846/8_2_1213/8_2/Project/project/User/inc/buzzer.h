#ifndef __BUZZER_H__
#define __BUZZER_H__

#define BUZZER_GPIO GPIOC
#define BUZZER_PIN	GPIO_Pin_11

void buzzer_Init(void);
void buzzer_on(void);
void buzzer_off(void);

#endif
