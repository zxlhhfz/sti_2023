
#include "main.h"

/***********************�궨��**********************/
#define START_STK_SIZE	128			//��������
#define START_PRIORITY	1

#define CONTROL_STK_SIZE	128		//��������
#define CONTROL_PRIORITY	2

#define COMMUNICATE_STK_SIZE	128		//��������
#define COMMUNICATE_PRIORITY	3


#define LED_STK_SIZE	128				//LED����
#define LED_PRIORITY	4

/********************����������*******************/
TaskFunction_t StartTask_Handler;
TaskFunction_t ControlTask_Handler;
TaskFunction_t LedTask_Handler;
TaskFunction_t CommunicateTask_Handler;

void Start_Task(void)
{
	xTaskCreate((TaskFunction_t ) start_task,
							(char * ) "start_task",
							(uint16_t ) START_STK_SIZE,
							(void * ) NULL,
							(UBaseType_t )START_PRIORITY,
							(TaskHandle_t * ) &StartTask_Handler );
}

void start_task(void *pvParameters)
{
	taskENTER_CRITICAL();		//�����ٽ���
	
	xTaskCreate((TaskFunction_t ) led_task,
						(char * ) "led_task",
						(uint16_t ) LED_STK_SIZE,
						(void * ) NULL,
						(UBaseType_t )LED_PRIORITY,
						(TaskHandle_t * ) &LedTask_Handler );
						
	xTaskCreate((TaskFunction_t ) control_task,
						(char * ) "control_task",
						(uint16_t ) CONTROL_STK_SIZE,
						(void * ) NULL,
						(UBaseType_t )CONTROL_PRIORITY,
						(TaskHandle_t * ) &ControlTask_Handler );		

	xTaskCreate((TaskFunction_t ) communicate_task,
						(char * ) "communicate_task",
						(uint16_t ) COMMUNICATE_STK_SIZE,
						(void * ) NULL,
						(UBaseType_t )COMMUNICATE_PRIORITY,
						(TaskHandle_t * ) &CommunicateTask_Handler );								
					
	vTaskDelete(StartTask_Handler);
						
	taskEXIT_CRITICAL();		//�˳��ٽ���
}
