#ifndef __HC05_H__
#define __HC05_H__





uint8_t	HC_05_ATCmd(char* cmd,uint16_t if_clean);
uint8_t HC_05_Config(void);


#endif
