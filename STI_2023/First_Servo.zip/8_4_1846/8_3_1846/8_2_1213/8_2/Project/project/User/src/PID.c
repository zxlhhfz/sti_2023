
#include "main.h"

void PID_Ref_Init(PID_Typedef *PID_typedef,float P,float I,
									float D,float T,float IMAX, float Out_max)
{
	PID_typedef->P = P;
	PID_typedef->I = I;
	PID_typedef->D = D;
	PID_typedef->IMAX = IMAX;
	PID_typedef->delta_T = T;
}

float PID_Cal(PID_Typedef *PID,float goal,float current)
{
	//�����ϴ����
	PID->last2_error =PID->last_error;
	PID->last_error =PID->current_error;
	PID->current_error =goal-current;
	PID->SumError +=PID->current_error;
	
	PID->Pout =PID->current_error*PID->P;
	PID->Iout =PID->SumError*PID->I;
	PID->Dout =(PID->last_error-PID->current_error)*PID->D;		//λ��ʽPID
	
	//�����޷�
	if(PID->IMAX < PID->Iout)
	{
		PID->Iout=PID->IMAX;
	}
	else if(-PID->IMAX > PID->Iout)
	{
		PID->Iout=(-PID->IMAX);
	}
	return (PID->Pout+PID->Iout+PID->Dout);		//�޷�
}

//��̨����PID�����������Ƶ�����ʽPID��
float Servo_PID_Cal(PID_Typedef *PID,float goal,float current)
{
	//�����ϴ����
	PID->last2_error =PID->last_error;
	PID->last_error =PID->current_error;
	PID->current_error =goal-current;
	PID->SumError +=PID->current_error;
	
	PID->Pout =PID->current_error*PID->P;
	PID->Iout =PID->SumError*PID->I;
	PID->Dout =(PID->current_error-2*PID->last_error+PID->last2_error)*PID->D;		
	
	//�����޷�
	if(PID->IMAX < PID->Iout)
	{
		PID->Iout=PID->IMAX;
	}
	else if(-PID->IMAX > PID->Iout)
	{
		PID->Iout=(-PID->IMAX);
	}
	
	if(PID->e0 !=0)		//��ʼ����������ֵ
	{
		
		if(PID->e0 >= fabsf(PID->current_error))
			return 0;
		else
			PID->Output = (PID->Pout+PID->Iout+PID->Dout);
	}
		PID->Output = (PID->Pout+PID->Iout+PID->Dout);
	
	return PID->Output;		
}
