
#include "main.h"

uint8_t grayscale_value[5];

void GrayScale_Sensor_GPIO_Init(void)
{
	GPIO_InitTypeDef gpio_init;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	gpio_init.GPIO_Pin=L2_PIN|L1_PIN|M_PIN|R1_PIN|R2_PIN;
	gpio_init.GPIO_Mode=GPIO_Mode_IPD;
	gpio_init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&gpio_init);
}

void GrayScale_Update(void)
{
	grayscale_value[0]= GPIO_ReadInputDataBit(GRAYSCALE_SENSOR_GPIO,L2_PIN);
	grayscale_value[1]= GPIO_ReadInputDataBit(GRAYSCALE_SENSOR_GPIO,L1_PIN);
	grayscale_value[2]= GPIO_ReadInputDataBit(GRAYSCALE_SENSOR_GPIO,M_PIN);
	grayscale_value[3]= GPIO_ReadInputDataBit(GRAYSCALE_SENSOR_GPIO,R1_PIN);
	grayscale_value[4]= GPIO_ReadInputDataBit(GRAYSCALE_SENSOR_GPIO,R2_PIN);
}
