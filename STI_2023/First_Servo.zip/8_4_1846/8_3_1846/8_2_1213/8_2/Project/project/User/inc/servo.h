#ifndef __SERVO_H__
#define __SERVO_H__

#include "stm32f10x.h"                  // Device header

//��һ����̨����
#define YAW_90	32.0
#define YAW_0		122.0
#define YAW_MINUS_90		208.0

#define PITCH_0	43.0
#define PITCH_20	63.0
#define PITCH_MINUS_15	34.0

//180����(�ڶ�����̨������
//#define YAW_90	0
//#define YAW_0		90.0
//#define YAW_MINUS_90		174.0

//#define PITCH_0	49.0
//#define PITCH_20	69.0
//#define PITCH_MINUS_15	32.0


#define YAW_MAX_ANGLE	(YAW_90/ 270* 2000 + 500)
#define YAW_MIN_ANGLE (YAW_MINUS_90/ 270* 2000 + 500)
#define PITCH_MAX_ANGLE	(PITCH_20/ 270* 2000 + 500)
#define PITCH_MIN_ANGLE	(PITCH_MINUS_15/ 270* 2000 + 500)


void TIM3_Servo_Init(void);
void Servo_Follow_Mode(void);
void Servo_SetAngle_yaw(float Angle);
void Servo_SetAngle_pitch(float Angle);

#endif



