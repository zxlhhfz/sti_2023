
#include "main.h"

//�̵�����ʼ��
//�͵�ƽ����
void Relay_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = RELAY_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(RELAY_GPIO, &GPIO_InitStructure);
	GPIO_SetBits(RELAY_GPIO, RELAY_PIN);
}


void lazer_off(void){
	GPIO_ResetBits(RELAY_GPIO, RELAY_PIN);
}

void lazer_on(void){
  GPIO_SetBits(RELAY_GPIO, RELAY_PIN);
}
