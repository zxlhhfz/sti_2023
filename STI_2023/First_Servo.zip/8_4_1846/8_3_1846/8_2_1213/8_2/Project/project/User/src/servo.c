#include "main.h"                  // Device header

extern Servo_typedef servo;		//����ṹ��

/**
  * @brief  TIM3��ʼ�� ��� PB0
  * @param  ��
  * @retval ��
  */
void TIM3_Servo_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_InternalClockConfig(TIM3);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period =20000  - 1;		//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);
	
	TIM_Cmd(TIM3, ENABLE);
}


void Servo_SetAngle_yaw(float Angle)
{
	//��ʼ�����ֵ
	servo.Servo_Output[YAW] = (float)Angle / 270 * 2000 + 500;
  TIM_SetCompare3(TIM3,(uint16_t)servo.Servo_Output[YAW]);
}

void Servo_SetAngle_pitch(float Angle)
{
	//��ʼ�����ֵ
	servo.Servo_Output[PITCH] = (float)Angle / 270 * 2000 + 500;
	TIM_SetCompare4(TIM3, (uint16_t)servo.Servo_Output[PITCH] );
}


extern uint8_t camera_x;			//Xλ��
extern uint8_t camera_y;			//Yλ��
extern uint8_t shape_type;		//��״

float servo_PID_temp;		//�洢PID����ֵ
//��̨׷��ģʽ
void Servo_Follow_Mode(void)
{
//	lazer_on();
//	servo_PID_temp = PID_Cal(&servo.Servo_POSITION_PID[YAW],CENTER_X,test_x);		//pid����ֵ
//	servo.Servo_Output[YAW] +=servo_PID_temp;
//	LIMIT_MAX_MIN(servo_PID_temp , servo.Servo_POSITION_PID[YAW].Out_max ,-servo.Servo_POSITION_PID[YAW].Out_max);
//	
//	if(servo.Servo_Output[YAW]>YAW_MIN_ANGLE)
//	{
//		servo.Servo_Output[YAW]= YAW_MIN_ANGLE;
//	}
//	else if(servo.Servo_Output[YAW]<YAW_MAX_ANGLE)
//	{
//		servo.Servo_Output[YAW]= YAW_MAX_ANGLE;
//	}
//	TIM_SetCompare3(TIM3,servo.Servo_Output[YAW]);
//	
//	servo_PID_temp = PID_Cal(&servo.Servo_POSITION_PID[PITCH],CENTER_Y,test_y);		//pid����ֵ
//	servo.Servo_Output[PITCH] +=servo_PID_temp;
//	LIMIT_MAX_MIN(servo_PID_temp , servo.Servo_POSITION_PID[PITCH].Out_max ,-servo.Servo_POSITION_PID[PITCH].Out_max);
//	if(servo.Servo_Output[PITCH]>PITCH_MAX_ANGLE)
//	{
//		servo.Servo_Output[PITCH]= PITCH_MAX_ANGLE;
//	}
//	else if(servo.Servo_Output[PITCH]<PITCH_MIN_ANGLE)
//	{
//		servo.Servo_Output[PITCH]= PITCH_MIN_ANGLE;
//	}
//	TIM_SetCompare4(TIM3,servo.Servo_Output[PITCH]);
}

