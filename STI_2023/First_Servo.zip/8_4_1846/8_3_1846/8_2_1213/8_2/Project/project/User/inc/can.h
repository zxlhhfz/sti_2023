
#ifndef __CAN_H
#define __CAN_H

#include "stm32f10x.h"

void CAN1_Init(void);
void CAN1_Receive_msg(void);
void USB_LP_CAN1_RX0_IRQHandler(void);
u8 Can_Send_Msg(u8* msg,u8 len);
 void CAN_GPIO_Config(void);
  void CAN_INIT(void);
	 void CAN_NVIC_Configuration(void);
	 void can_tx(u8 Data1,u8 Data2);
	 void Can_TxByte(u8 *Data,u8 len);

#endif
