
#ifndef __MAIN_H
#define __MAIN_H

/* FreeRTOSͷ�ļ� */
#include "FreeRTOS.h"
#include "task.h"
#include "portmacro.h"
#include "queue.h"
#include "semphr.h"

/* ��ͷ�ļ� */
#include <jansson.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "cJSON.h"

/* �û�ͷ�ļ� */
#include "stm32f10x.h"
#include "PID.h"
#include "delay.h"
#include "sys.h"

/* �豸ͷ�ļ� */
#include "grayscale_sensor.h"
#include "TIM.h"
#include "USART.h"
#include "IIC.h"
#include "INA219.h"
#include "MPU6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "led.h"
#include "servo.h"
#include "HC05.h"
#include "buzzer.h"
#include "JY60.h"
#include "Relay.h"
#include "AD.h"
#include "can.h"
#include "step_motot.h"		//�������
#include <string.h>

/*�Զ��������ļ�*/
#include "start_task.h"
#include "led_task.h"
#include "Control_Task.h"
#include "Communicate_task.h"


#define PI 	3. 141592653589
#define ADC_BUFFERSIZE	5
void BSP_Init(void);
void Ref_Init(void);
float LIMIT_MAX_MIN(float x,float max,float min);

#endif
