
#ifndef __RELAY_H
#define __RELAY_H

#include "stm32f10x.h"

#define RELAY_PIN		GPIO_Pin_8
#define RELAY_GPIO	GPIOC

void Relay_Init(void);
void lazer_on(void);
void lazer_off(void);


#endif
